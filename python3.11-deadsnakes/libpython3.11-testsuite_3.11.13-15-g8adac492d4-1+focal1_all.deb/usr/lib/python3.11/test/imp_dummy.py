# Fodder for test of issue24748 in test_imp

dummy_name = True
